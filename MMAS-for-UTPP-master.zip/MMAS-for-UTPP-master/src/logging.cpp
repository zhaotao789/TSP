#include "logging.h"

#define LOGURU_IMPLEMENTATION 1
#include "loguru.hpp"
