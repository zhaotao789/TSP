[
    {
        "best_markets": 50, 
        "K": 50, 
        "best_cost": 46794, 
        "name": "CapEuclideo.50.50.1.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 50, 
        "best_cost": 48120, 
        "name": "CapEuclideo.50.50.1.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 50, 
        "best_cost": 42861, 
        "name": "CapEuclideo.50.50.1.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 50, 
        "best_cost": 42920, 
        "name": "CapEuclideo.50.50.1.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 47, 
        "K": 50, 
        "best_cost": 40562, 
        "name": "CapEuclideo.50.50.1.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 46, 
        "K": 50, 
        "best_cost": 17980, 
        "name": "CapEuclideo.50.50.5.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 48, 
        "K": 50, 
        "best_cost": 18449, 
        "name": "CapEuclideo.50.50.5.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 46, 
        "K": 50, 
        "best_cost": 16653, 
        "name": "CapEuclideo.50.50.5.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 46, 
        "K": 50, 
        "best_cost": 16196, 
        "name": "CapEuclideo.50.50.5.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 45, 
        "K": 50, 
        "best_cost": 15844, 
        "name": "CapEuclideo.50.50.5.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 40, 
        "K": 50, 
        "best_cost": 9013, 
        "name": "CapEuclideo.50.50.7.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 44, 
        "K": 50, 
        "best_cost": 9484, 
        "name": "CapEuclideo.50.50.7.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 42, 
        "K": 50, 
        "best_cost": 8752, 
        "name": "CapEuclideo.50.50.7.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 39, 
        "K": 50, 
        "best_cost": 8635, 
        "name": "CapEuclideo.50.50.7.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 38, 
        "K": 50, 
        "best_cost": 8620, 
        "name": "CapEuclideo.50.50.7.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 35, 
        "K": 50, 
        "best_cost": 6287, 
        "name": "CapEuclideo.50.50.8.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 36, 
        "K": 50, 
        "best_cost": 6258, 
        "name": "CapEuclideo.50.50.8.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 31, 
        "K": 50, 
        "best_cost": 5846, 
        "name": "CapEuclideo.50.50.8.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 29, 
        "K": 50, 
        "best_cost": 5573, 
        "name": "CapEuclideo.50.50.8.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 32, 
        "K": 50, 
        "best_cost": 5827, 
        "name": "CapEuclideo.50.50.8.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 24, 
        "K": 50, 
        "best_cost": 3650, 
        "name": "CapEuclideo.50.50.9.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 25, 
        "K": 50, 
        "best_cost": 3811, 
        "name": "CapEuclideo.50.50.9.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 22, 
        "K": 50, 
        "best_cost": 3522, 
        "name": "CapEuclideo.50.50.9.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 21, 
        "K": 50, 
        "best_cost": 3329, 
        "name": "CapEuclideo.50.50.9.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 18, 
        "K": 50, 
        "best_cost": 3543, 
        "name": "CapEuclideo.50.50.9.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 18, 
        "K": 50, 
        "best_cost": 2636, 
        "name": "CapEuclideo.50.50.95.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 17, 
        "K": 50, 
        "best_cost": 1758, 
        "name": "CapEuclideo.50.50.95.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 50, 
        "best_cost": 2390, 
        "name": "CapEuclideo.50.50.95.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 16, 
        "K": 50, 
        "best_cost": 2643, 
        "name": "CapEuclideo.50.50.95.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 15, 
        "K": 50, 
        "best_cost": 2792, 
        "name": "CapEuclideo.50.50.95.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 8, 
        "K": 50, 
        "best_cost": 1703, 
        "name": "CapEuclideo.50.50.99.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 50, 
        "best_cost": 1305, 
        "name": "CapEuclideo.50.50.99.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 11, 
        "K": 50, 
        "best_cost": 1893, 
        "name": "CapEuclideo.50.50.99.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 2143, 
        "name": "CapEuclideo.50.50.99.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 12, 
        "K": 50, 
        "best_cost": 2266, 
        "name": "CapEuclideo.50.50.99.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 83044, 
        "name": "CapEuclideo.50.100.1.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 87427, 
        "name": "CapEuclideo.50.100.1.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 85002, 
        "name": "CapEuclideo.50.100.1.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 89756, 
        "name": "CapEuclideo.50.100.1.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 87090, 
        "name": "CapEuclideo.50.100.1.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 29334, 
        "name": "CapEuclideo.50.100.5.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 30089, 
        "name": "CapEuclideo.50.100.5.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 29016, 
        "name": "CapEuclideo.50.100.5.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 29913, 
        "name": "CapEuclideo.50.100.5.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 100, 
        "best_cost": 29503, 
        "name": "CapEuclideo.50.100.5.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 49, 
        "K": 100, 
        "best_cost": 14066, 
        "name": "CapEuclideo.50.100.7.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 47, 
        "K": 100, 
        "best_cost": 13536, 
        "name": "CapEuclideo.50.100.7.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 43, 
        "K": 100, 
        "best_cost": 12934, 
        "name": "CapEuclideo.50.100.7.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 47, 
        "K": 100, 
        "best_cost": 13475, 
        "name": "CapEuclideo.50.100.7.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 44, 
        "K": 100, 
        "best_cost": 13686, 
        "name": "CapEuclideo.50.100.7.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 35, 
        "K": 100, 
        "best_cost": 8441, 
        "name": "CapEuclideo.50.100.8.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 36, 
        "K": 100, 
        "best_cost": 7940, 
        "name": "CapEuclideo.50.100.8.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 37, 
        "K": 100, 
        "best_cost": 7831, 
        "name": "CapEuclideo.50.100.8.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 38, 
        "K": 100, 
        "best_cost": 8230, 
        "name": "CapEuclideo.50.100.8.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 37, 
        "K": 100, 
        "best_cost": 8520, 
        "name": "CapEuclideo.50.100.8.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 27, 
        "K": 100, 
        "best_cost": 4718, 
        "name": "CapEuclideo.50.100.9.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 31, 
        "K": 100, 
        "best_cost": 4705, 
        "name": "CapEuclideo.50.100.9.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 31, 
        "K": 100, 
        "best_cost": 4462, 
        "name": "CapEuclideo.50.100.9.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 31, 
        "K": 100, 
        "best_cost": 4620, 
        "name": "CapEuclideo.50.100.9.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 32, 
        "K": 100, 
        "best_cost": 4834, 
        "name": "CapEuclideo.50.100.9.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 19, 
        "K": 100, 
        "best_cost": 3429, 
        "name": "CapEuclideo.50.100.95.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 21, 
        "K": 100, 
        "best_cost": 3226, 
        "name": "CapEuclideo.50.100.95.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 19, 
        "K": 100, 
        "best_cost": 2818, 
        "name": "CapEuclideo.50.100.95.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 22, 
        "K": 100, 
        "best_cost": 3190, 
        "name": "CapEuclideo.50.100.95.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 21, 
        "K": 100, 
        "best_cost": 3273, 
        "name": "CapEuclideo.50.100.95.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 100, 
        "best_cost": 2389, 
        "name": "CapEuclideo.50.100.99.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 16, 
        "K": 100, 
        "best_cost": 1986, 
        "name": "CapEuclideo.50.100.99.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 100, 
        "best_cost": 2091, 
        "name": "CapEuclideo.50.100.99.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 18, 
        "K": 100, 
        "best_cost": 2519, 
        "name": "CapEuclideo.50.100.99.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 2580, 
        "name": "CapEuclideo.50.100.99.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 126600, 
        "name": "CapEuclideo.50.150.1.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 128380, 
        "name": "CapEuclideo.50.150.1.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 127979, 
        "name": "CapEuclideo.50.150.1.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 130088, 
        "name": "CapEuclideo.50.150.1.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 126927, 
        "name": "CapEuclideo.50.150.1.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 42092, 
        "name": "CapEuclideo.50.150.5.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 42006, 
        "name": "CapEuclideo.50.150.5.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 41891, 
        "name": "CapEuclideo.50.150.5.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 42116, 
        "name": "CapEuclideo.50.150.5.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 41300, 
        "name": "CapEuclideo.50.150.5.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 48, 
        "K": 150, 
        "best_cost": 18497, 
        "name": "CapEuclideo.50.150.7.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 48, 
        "K": 150, 
        "best_cost": 17710, 
        "name": "CapEuclideo.50.150.7.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 46, 
        "K": 150, 
        "best_cost": 17665, 
        "name": "CapEuclideo.50.150.7.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 17964, 
        "name": "CapEuclideo.50.150.7.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 18236, 
        "name": "CapEuclideo.50.150.7.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 45, 
        "K": 150, 
        "best_cost": 11088, 
        "name": "CapEuclideo.50.150.8.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 48, 
        "K": 150, 
        "best_cost": 10188, 
        "name": "CapEuclideo.50.150.8.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 46, 
        "K": 150, 
        "best_cost": 10565, 
        "name": "CapEuclideo.50.150.8.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 150, 
        "best_cost": 10573, 
        "name": "CapEuclideo.50.150.8.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 45, 
        "K": 150, 
        "best_cost": 10986, 
        "name": "CapEuclideo.50.150.8.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 33, 
        "K": 150, 
        "best_cost": 5789, 
        "name": "CapEuclideo.50.150.9.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 34, 
        "K": 150, 
        "best_cost": 5381, 
        "name": "CapEuclideo.50.150.9.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 34, 
        "K": 150, 
        "best_cost": 5479, 
        "name": "CapEuclideo.50.150.9.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 39, 
        "K": 150, 
        "best_cost": 5543, 
        "name": "CapEuclideo.50.150.9.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 35, 
        "K": 150, 
        "best_cost": 5979, 
        "name": "CapEuclideo.50.150.9.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 27, 
        "K": 150, 
        "best_cost": 4157, 
        "name": "CapEuclideo.50.150.95.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 25, 
        "K": 150, 
        "best_cost": 3808, 
        "name": "CapEuclideo.50.150.95.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 22, 
        "K": 150, 
        "best_cost": 3588, 
        "name": "CapEuclideo.50.150.95.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 23, 
        "K": 150, 
        "best_cost": 3681, 
        "name": "CapEuclideo.50.150.95.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 27, 
        "K": 150, 
        "best_cost": 4044, 
        "name": "CapEuclideo.50.150.95.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 22, 
        "K": 150, 
        "best_cost": 3239, 
        "name": "CapEuclideo.50.150.99.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 150, 
        "best_cost": 2761, 
        "name": "CapEuclideo.50.150.99.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 11, 
        "K": 150, 
        "best_cost": 2012, 
        "name": "CapEuclideo.50.150.99.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 15, 
        "K": 150, 
        "best_cost": 2532, 
        "name": "CapEuclideo.50.150.99.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 150, 
        "best_cost": 3240, 
        "name": "CapEuclideo.50.150.99.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 163462, 
        "name": "CapEuclideo.50.200.1.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 167145, 
        "name": "CapEuclideo.50.200.1.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 173014, 
        "name": "CapEuclideo.50.200.1.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 174836, 
        "name": "CapEuclideo.50.200.1.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 168189, 
        "name": "CapEuclideo.50.200.1.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 53186, 
        "name": "CapEuclideo.50.200.5.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 53628, 
        "name": "CapEuclideo.50.200.5.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 54911, 
        "name": "CapEuclideo.50.200.5.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 55905, 
        "name": "CapEuclideo.50.200.5.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 53661, 
        "name": "CapEuclideo.50.200.5.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 22626, 
        "name": "CapEuclideo.50.200.7.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 21912, 
        "name": "CapEuclideo.50.200.7.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 22386, 
        "name": "CapEuclideo.50.200.7.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 22927, 
        "name": "CapEuclideo.50.200.7.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 22594, 
        "name": "CapEuclideo.50.200.7.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 47, 
        "K": 200, 
        "best_cost": 12519, 
        "name": "CapEuclideo.50.200.8.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 45, 
        "K": 200, 
        "best_cost": 12108, 
        "name": "CapEuclideo.50.200.8.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 45, 
        "K": 200, 
        "best_cost": 12431, 
        "name": "CapEuclideo.50.200.8.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 48, 
        "K": 200, 
        "best_cost": 12717, 
        "name": "CapEuclideo.50.200.8.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 44, 
        "K": 200, 
        "best_cost": 12612, 
        "name": "CapEuclideo.50.200.8.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 36, 
        "K": 200, 
        "best_cost": 6523, 
        "name": "CapEuclideo.50.200.9.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 41, 
        "K": 200, 
        "best_cost": 6213, 
        "name": "CapEuclideo.50.200.9.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 38, 
        "K": 200, 
        "best_cost": 6241, 
        "name": "CapEuclideo.50.200.9.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 40, 
        "K": 200, 
        "best_cost": 6444, 
        "name": "CapEuclideo.50.200.9.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 36, 
        "K": 200, 
        "best_cost": 6534, 
        "name": "CapEuclideo.50.200.9.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 29, 
        "K": 200, 
        "best_cost": 4306, 
        "name": "CapEuclideo.50.200.95.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 32, 
        "K": 200, 
        "best_cost": 4553, 
        "name": "CapEuclideo.50.200.95.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 27, 
        "K": 200, 
        "best_cost": 4005, 
        "name": "CapEuclideo.50.200.95.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 26, 
        "K": 200, 
        "best_cost": 4072, 
        "name": "CapEuclideo.50.200.95.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 29, 
        "K": 200, 
        "best_cost": 4805, 
        "name": "CapEuclideo.50.200.95.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 15, 
        "K": 200, 
        "best_cost": 2414, 
        "name": "CapEuclideo.50.200.99.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 200, 
        "best_cost": 2770, 
        "name": "CapEuclideo.50.200.99.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 14, 
        "K": 200, 
        "best_cost": 2440, 
        "name": "CapEuclideo.50.200.99.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 18, 
        "K": 200, 
        "best_cost": 2627, 
        "name": "CapEuclideo.50.200.99.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 22, 
        "K": 200, 
        "best_cost": 3704, 
        "name": "CapEuclideo.50.200.99.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 93291, 
        "name": "CapEuclideo.100.50.1.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 93710, 
        "name": "CapEuclideo.100.50.1.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 86395, 
        "name": "CapEuclideo.100.50.1.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 92922, 
        "name": "CapEuclideo.100.50.1.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 81486, 
        "name": "CapEuclideo.100.50.1.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 33174, 
        "name": "CapEuclideo.100.50.5.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 33050, 
        "name": "CapEuclideo.100.50.5.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 30223, 
        "name": "CapEuclideo.100.50.5.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 32249, 
        "name": "CapEuclideo.100.50.5.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 50, 
        "best_cost": 28275, 
        "name": "CapEuclideo.100.50.5.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 88, 
        "K": 50, 
        "best_cost": 15801, 
        "name": "CapEuclideo.100.50.7.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 90, 
        "K": 50, 
        "best_cost": 15665, 
        "name": "CapEuclideo.100.50.7.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 87, 
        "K": 50, 
        "best_cost": 14358, 
        "name": "CapEuclideo.100.50.7.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 90, 
        "K": 50, 
        "best_cost": 15418, 
        "name": "CapEuclideo.100.50.7.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 84, 
        "K": 50, 
        "best_cost": 13746, 
        "name": "CapEuclideo.100.50.7.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 75, 
        "K": 50, 
        "best_cost": 9856, 
        "name": "CapEuclideo.100.50.8.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 64, 
        "K": 50, 
        "best_cost": 9745, 
        "name": "CapEuclideo.100.50.8.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 68, 
        "K": 50, 
        "best_cost": 8756, 
        "name": "CapEuclideo.100.50.8.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 74, 
        "K": 50, 
        "best_cost": 9574, 
        "name": "CapEuclideo.100.50.8.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 69, 
        "K": 50, 
        "best_cost": 8691, 
        "name": "CapEuclideo.100.50.8.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 46, 
        "K": 50, 
        "best_cost": 4847, 
        "name": "CapEuclideo.100.50.9.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 35, 
        "K": 50, 
        "best_cost": 4672, 
        "name": "CapEuclideo.100.50.9.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 43, 
        "K": 50, 
        "best_cost": 4381, 
        "name": "CapEuclideo.100.50.9.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 41, 
        "K": 50, 
        "best_cost": 4961, 
        "name": "CapEuclideo.100.50.9.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 37, 
        "K": 50, 
        "best_cost": 4607, 
        "name": "CapEuclideo.100.50.9.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 30, 
        "K": 50, 
        "best_cost": 2699, 
        "name": "CapEuclideo.100.50.95.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 25, 
        "K": 50, 
        "best_cost": 2685, 
        "name": "CapEuclideo.100.50.95.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 22, 
        "K": 50, 
        "best_cost": 2649, 
        "name": "CapEuclideo.100.50.95.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 25, 
        "K": 50, 
        "best_cost": 3272, 
        "name": "CapEuclideo.100.50.95.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 23, 
        "K": 50, 
        "best_cost": 2995, 
        "name": "CapEuclideo.100.50.95.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 1313, 
        "name": "CapEuclideo.100.50.99.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 14, 
        "K": 50, 
        "best_cost": 1367, 
        "name": "CapEuclideo.100.50.99.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 10, 
        "K": 50, 
        "best_cost": 1146, 
        "name": "CapEuclideo.100.50.99.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 16, 
        "K": 50, 
        "best_cost": 2217, 
        "name": "CapEuclideo.100.50.99.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 10, 
        "K": 50, 
        "best_cost": 1475, 
        "name": "CapEuclideo.100.50.99.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 168075, 
        "name": "CapEuclideo.100.100.1.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 164651, 
        "name": "CapEuclideo.100.100.1.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 160410, 
        "name": "CapEuclideo.100.100.1.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 181984, 
        "name": "CapEuclideo.100.100.1.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 160015, 
        "name": "CapEuclideo.100.100.1.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 54900, 
        "name": "CapEuclideo.100.100.5.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 53279, 
        "name": "CapEuclideo.100.100.5.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 51671, 
        "name": "CapEuclideo.100.100.5.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 58641, 
        "name": "CapEuclideo.100.100.5.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 50902, 
        "name": "CapEuclideo.100.100.5.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 85, 
        "K": 100, 
        "best_cost": 23250, 
        "name": "CapEuclideo.100.100.7.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 88, 
        "K": 100, 
        "best_cost": 21961, 
        "name": "CapEuclideo.100.100.7.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 85, 
        "K": 100, 
        "best_cost": 21537, 
        "name": "CapEuclideo.100.100.7.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 97, 
        "K": 100, 
        "best_cost": 24555, 
        "name": "CapEuclideo.100.100.7.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 100, 
        "best_cost": 22067, 
        "name": "CapEuclideo.100.100.7.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 88, 
        "K": 100, 
        "best_cost": 13673, 
        "name": "CapEuclideo.100.100.8.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 88, 
        "K": 100, 
        "best_cost": 12877, 
        "name": "CapEuclideo.100.100.8.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 87, 
        "K": 100, 
        "best_cost": 12642, 
        "name": "CapEuclideo.100.100.8.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 94, 
        "K": 100, 
        "best_cost": 14087, 
        "name": "CapEuclideo.100.100.8.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 85, 
        "K": 100, 
        "best_cost": 12854, 
        "name": "CapEuclideo.100.100.8.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 59, 
        "K": 100, 
        "best_cost": 6494, 
        "name": "CapEuclideo.100.100.9.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 60, 
        "K": 100, 
        "best_cost": 6375, 
        "name": "CapEuclideo.100.100.9.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 52, 
        "K": 100, 
        "best_cost": 6063, 
        "name": "CapEuclideo.100.100.9.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 62, 
        "K": 100, 
        "best_cost": 6863, 
        "name": "CapEuclideo.100.100.9.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 56, 
        "K": 100, 
        "best_cost": 6415, 
        "name": "CapEuclideo.100.100.9.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 34, 
        "K": 100, 
        "best_cost": 3484, 
        "name": "CapEuclideo.100.100.95.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 31, 
        "K": 100, 
        "best_cost": 3468, 
        "name": "CapEuclideo.100.100.95.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 34, 
        "K": 100, 
        "best_cost": 3491, 
        "name": "CapEuclideo.100.100.95.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 28, 
        "K": 100, 
        "best_cost": 3532, 
        "name": "CapEuclideo.100.100.95.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 33, 
        "K": 100, 
        "best_cost": 3802, 
        "name": "CapEuclideo.100.100.95.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 15, 
        "K": 100, 
        "best_cost": 1539, 
        "name": "CapEuclideo.100.100.99.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 15, 
        "K": 100, 
        "best_cost": 1554, 
        "name": "CapEuclideo.100.100.99.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 1672, 
        "name": "CapEuclideo.100.100.99.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 20, 
        "K": 100, 
        "best_cost": 2168, 
        "name": "CapEuclideo.100.100.99.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 21, 
        "K": 100, 
        "best_cost": 2394, 
        "name": "CapEuclideo.100.100.99.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 254921, 
        "name": "CapEuclideo.100.150.1.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 249585, 
        "name": "CapEuclideo.100.150.1.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 247800, 
        "name": "CapEuclideo.100.150.1.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 261499, 
        "name": "CapEuclideo.100.150.1.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 238058, 
        "name": "CapEuclideo.100.150.1.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 80460, 
        "name": "CapEuclideo.100.150.5.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 78721, 
        "name": "CapEuclideo.100.150.5.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 77133, 
        "name": "CapEuclideo.100.150.5.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 95, 
        "K": 150, 
        "best_cost": 81415, 
        "name": "CapEuclideo.100.150.5.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 94, 
        "K": 150, 
        "best_cost": 73903, 
        "name": "CapEuclideo.100.150.5.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 99, 
        "K": 150, 
        "best_cost": 31977, 
        "name": "CapEuclideo.100.150.7.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 31133, 
        "name": "CapEuclideo.100.150.7.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 30574, 
        "name": "CapEuclideo.100.150.7.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 32307, 
        "name": "CapEuclideo.100.150.7.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 150, 
        "best_cost": 29984, 
        "name": "CapEuclideo.100.150.7.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 95, 
        "K": 150, 
        "best_cost": 17320, 
        "name": "CapEuclideo.100.150.8.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 93, 
        "K": 150, 
        "best_cost": 16500, 
        "name": "CapEuclideo.100.150.8.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 93, 
        "K": 150, 
        "best_cost": 16387, 
        "name": "CapEuclideo.100.150.8.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 97, 
        "K": 150, 
        "best_cost": 17202, 
        "name": "CapEuclideo.100.150.8.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 90, 
        "K": 150, 
        "best_cost": 16458, 
        "name": "CapEuclideo.100.150.8.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 65, 
        "K": 150, 
        "best_cost": 7358, 
        "name": "CapEuclideo.100.150.9.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 59, 
        "K": 150, 
        "best_cost": 7342, 
        "name": "CapEuclideo.100.150.9.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 60, 
        "K": 150, 
        "best_cost": 6962, 
        "name": "CapEuclideo.100.150.9.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 70, 
        "K": 150, 
        "best_cost": 7960, 
        "name": "CapEuclideo.100.150.9.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 67, 
        "K": 150, 
        "best_cost": 7766, 
        "name": "CapEuclideo.100.150.9.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 41, 
        "K": 150, 
        "best_cost": 4436, 
        "name": "CapEuclideo.100.150.95.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 44, 
        "K": 150, 
        "best_cost": 4409, 
        "name": "CapEuclideo.100.150.95.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 43, 
        "K": 150, 
        "best_cost": 4068, 
        "name": "CapEuclideo.100.150.95.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 45, 
        "K": 150, 
        "best_cost": 4747, 
        "name": "CapEuclideo.100.150.95.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 43, 
        "K": 150, 
        "best_cost": 4663, 
        "name": "CapEuclideo.100.150.95.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 1978, 
        "name": "CapEuclideo.100.150.99.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 2212, 
        "name": "CapEuclideo.100.150.99.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 24, 
        "K": 150, 
        "best_cost": 2122, 
        "name": "CapEuclideo.100.150.99.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 2336, 
        "name": "CapEuclideo.100.150.99.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 15, 
        "K": 150, 
        "best_cost": 2468, 
        "name": "CapEuclideo.100.150.99.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 339322, 
        "name": "CapEuclideo.100.200.1.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 328970, 
        "name": "CapEuclideo.100.200.1.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 320623, 
        "name": "CapEuclideo.100.200.1.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 331657, 
        "name": "CapEuclideo.100.200.1.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 311129, 
        "name": "CapEuclideo.100.200.1.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 105300, 
        "name": "CapEuclideo.100.200.5.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 101942, 
        "name": "CapEuclideo.100.200.5.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 97956, 
        "name": "CapEuclideo.100.200.5.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 102405, 
        "name": "CapEuclideo.100.200.5.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 95206, 
        "name": "CapEuclideo.100.200.5.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 40403, 
        "name": "CapEuclideo.100.200.7.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 38937, 
        "name": "CapEuclideo.100.200.7.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 37685, 
        "name": "CapEuclideo.100.200.7.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 39483, 
        "name": "CapEuclideo.100.200.7.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 36897, 
        "name": "CapEuclideo.100.200.7.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 99, 
        "K": 200, 
        "best_cost": 20659, 
        "name": "CapEuclideo.100.200.8.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 100, 
        "K": 200, 
        "best_cost": 19918, 
        "name": "CapEuclideo.100.200.8.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 98, 
        "K": 200, 
        "best_cost": 19273, 
        "name": "CapEuclideo.100.200.8.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 88, 
        "K": 200, 
        "best_cost": 19898, 
        "name": "CapEuclideo.100.200.8.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 99, 
        "K": 200, 
        "best_cost": 19521, 
        "name": "CapEuclideo.100.200.8.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 74, 
        "K": 200, 
        "best_cost": 8544, 
        "name": "CapEuclideo.100.200.9.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 76, 
        "K": 200, 
        "best_cost": 8830, 
        "name": "CapEuclideo.100.200.9.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 72, 
        "K": 200, 
        "best_cost": 8342, 
        "name": "CapEuclideo.100.200.9.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 68, 
        "K": 200, 
        "best_cost": 8485, 
        "name": "CapEuclideo.100.200.9.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 72, 
        "K": 200, 
        "best_cost": 8745, 
        "name": "CapEuclideo.100.200.9.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 46, 
        "K": 200, 
        "best_cost": 4733, 
        "name": "CapEuclideo.100.200.95.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 49, 
        "K": 200, 
        "best_cost": 4658, 
        "name": "CapEuclideo.100.200.95.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 45, 
        "K": 200, 
        "best_cost": 4333, 
        "name": "CapEuclideo.100.200.95.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 48, 
        "K": 200, 
        "best_cost": 5096, 
        "name": "CapEuclideo.100.200.95.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 50, 
        "K": 200, 
        "best_cost": 5115, 
        "name": "CapEuclideo.100.200.95.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 22, 
        "K": 200, 
        "best_cost": 2508, 
        "name": "CapEuclideo.100.200.99.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 29, 
        "K": 200, 
        "best_cost": 2901, 
        "name": "CapEuclideo.100.200.99.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 24, 
        "K": 200, 
        "best_cost": 2267, 
        "name": "CapEuclideo.100.200.99.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 26, 
        "K": 200, 
        "best_cost": 2987, 
        "name": "CapEuclideo.100.200.99.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 22, 
        "K": 200, 
        "best_cost": 2685, 
        "name": "CapEuclideo.100.200.99.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 150, 
        "K": 50, 
        "best_cost": 125418, 
        "name": "CapEuclideo.150.50.1.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 50, 
        "best_cost": 125650, 
        "name": "CapEuclideo.150.50.1.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 50, 
        "best_cost": 143310, 
        "name": "CapEuclideo.150.50.1.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 146, 
        "K": 50, 
        "best_cost": 135503, 
        "name": "CapEuclideo.150.50.1.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 50, 
        "best_cost": 126023, 
        "name": "CapEuclideo.150.50.1.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 145, 
        "K": 50, 
        "best_cost": 43115, 
        "name": "CapEuclideo.150.50.5.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 50, 
        "best_cost": 42669, 
        "name": "CapEuclideo.150.50.5.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 50, 
        "best_cost": 47455, 
        "name": "CapEuclideo.150.50.5.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 50, 
        "best_cost": 45556, 
        "name": "CapEuclideo.150.50.5.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 50, 
        "best_cost": 41937, 
        "name": "CapEuclideo.150.50.5.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 133, 
        "K": 50, 
        "best_cost": 20264, 
        "name": "CapEuclideo.150.50.7.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 133, 
        "K": 50, 
        "best_cost": 19621, 
        "name": "CapEuclideo.150.50.7.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 132, 
        "K": 50, 
        "best_cost": 20671, 
        "name": "CapEuclideo.150.50.7.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 126, 
        "K": 50, 
        "best_cost": 20472, 
        "name": "CapEuclideo.150.50.7.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 140, 
        "K": 50, 
        "best_cost": 19554, 
        "name": "CapEuclideo.150.50.7.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 102, 
        "K": 50, 
        "best_cost": 12448, 
        "name": "CapEuclideo.150.50.8.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 103, 
        "K": 50, 
        "best_cost": 11817, 
        "name": "CapEuclideo.150.50.8.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 114, 
        "K": 50, 
        "best_cost": 12538, 
        "name": "CapEuclideo.150.50.8.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 112, 
        "K": 50, 
        "best_cost": 12622, 
        "name": "CapEuclideo.150.50.8.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 113, 
        "K": 50, 
        "best_cost": 11711, 
        "name": "CapEuclideo.150.50.8.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 57, 
        "K": 50, 
        "best_cost": 5360, 
        "name": "CapEuclideo.150.50.9.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 62, 
        "K": 50, 
        "best_cost": 5571, 
        "name": "CapEuclideo.150.50.9.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 68, 
        "K": 50, 
        "best_cost": 6097, 
        "name": "CapEuclideo.150.50.9.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 65, 
        "K": 50, 
        "best_cost": 6152, 
        "name": "CapEuclideo.150.50.9.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 63, 
        "K": 50, 
        "best_cost": 5879, 
        "name": "CapEuclideo.150.50.9.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 35, 
        "K": 50, 
        "best_cost": 2986, 
        "name": "CapEuclideo.150.50.95.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 34, 
        "K": 50, 
        "best_cost": 3031, 
        "name": "CapEuclideo.150.50.95.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 37, 
        "K": 50, 
        "best_cost": 3214, 
        "name": "CapEuclideo.150.50.95.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 37, 
        "K": 50, 
        "best_cost": 3633, 
        "name": "CapEuclideo.150.50.95.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 34, 
        "K": 50, 
        "best_cost": 3337, 
        "name": "CapEuclideo.150.50.95.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 1894, 
        "name": "CapEuclideo.150.50.99.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 17, 
        "K": 50, 
        "best_cost": 1477, 
        "name": "CapEuclideo.150.50.99.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 15, 
        "K": 50, 
        "best_cost": 1171, 
        "name": "CapEuclideo.150.50.99.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 12, 
        "K": 50, 
        "best_cost": 1345, 
        "name": "CapEuclideo.150.50.99.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 16, 
        "K": 50, 
        "best_cost": 1322, 
        "name": "CapEuclideo.150.50.99.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 223506, 
        "name": "CapEuclideo.150.100.1.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 239549, 
        "name": "CapEuclideo.150.100.1.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 148, 
        "K": 100, 
        "best_cost": 263750, 
        "name": "CapEuclideo.150.100.1.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 276734, 
        "name": "CapEuclideo.150.100.1.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 246932, 
        "name": "CapEuclideo.150.100.1.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 72000, 
        "name": "CapEuclideo.150.100.5.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 76195, 
        "name": "CapEuclideo.150.100.5.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 100, 
        "best_cost": 82063, 
        "name": "CapEuclideo.150.100.5.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 86567, 
        "name": "CapEuclideo.150.100.5.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 76916, 
        "name": "CapEuclideo.150.100.5.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 148, 
        "K": 100, 
        "best_cost": 30171, 
        "name": "CapEuclideo.150.100.7.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 148, 
        "K": 100, 
        "best_cost": 31253, 
        "name": "CapEuclideo.150.100.7.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 32784, 
        "name": "CapEuclideo.150.100.7.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 144, 
        "K": 100, 
        "best_cost": 34829, 
        "name": "CapEuclideo.150.100.7.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 100, 
        "best_cost": 31308, 
        "name": "CapEuclideo.150.100.7.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 129, 
        "K": 100, 
        "best_cost": 17015, 
        "name": "CapEuclideo.150.100.8.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 136, 
        "K": 100, 
        "best_cost": 17357, 
        "name": "CapEuclideo.150.100.8.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 137, 
        "K": 100, 
        "best_cost": 17798, 
        "name": "CapEuclideo.150.100.8.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 137, 
        "K": 100, 
        "best_cost": 18661, 
        "name": "CapEuclideo.150.100.8.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 138, 
        "K": 100, 
        "best_cost": 17407, 
        "name": "CapEuclideo.150.100.8.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 88, 
        "K": 100, 
        "best_cost": 7922, 
        "name": "CapEuclideo.150.100.9.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 92, 
        "K": 100, 
        "best_cost": 8090, 
        "name": "CapEuclideo.150.100.9.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 90, 
        "K": 100, 
        "best_cost": 7988, 
        "name": "CapEuclideo.150.100.9.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 86, 
        "K": 100, 
        "best_cost": 8267, 
        "name": "CapEuclideo.150.100.9.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 87, 
        "K": 100, 
        "best_cost": 7918, 
        "name": "CapEuclideo.150.100.9.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 58, 
        "K": 100, 
        "best_cost": 4455, 
        "name": "CapEuclideo.150.100.95.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 53, 
        "K": 100, 
        "best_cost": 4602, 
        "name": "CapEuclideo.150.100.95.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 49, 
        "K": 100, 
        "best_cost": 4293, 
        "name": "CapEuclideo.150.100.95.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 53, 
        "K": 100, 
        "best_cost": 4655, 
        "name": "CapEuclideo.150.100.95.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 48, 
        "K": 100, 
        "best_cost": 4577, 
        "name": "CapEuclideo.150.100.95.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 24, 
        "K": 100, 
        "best_cost": 1710, 
        "name": "CapEuclideo.150.100.99.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 23, 
        "K": 100, 
        "best_cost": 2222, 
        "name": "CapEuclideo.150.100.99.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 18, 
        "K": 100, 
        "best_cost": 1544, 
        "name": "CapEuclideo.150.100.99.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 25, 
        "K": 100, 
        "best_cost": 2314, 
        "name": "CapEuclideo.150.100.99.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 20, 
        "K": 100, 
        "best_cost": 2140, 
        "name": "CapEuclideo.150.100.99.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 344600, 
        "name": "CapEuclideo.150.150.1.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 354253, 
        "name": "CapEuclideo.150.150.1.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 389949, 
        "name": "CapEuclideo.150.150.1.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 404653, 
        "name": "CapEuclideo.150.150.1.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 358584, 
        "name": "CapEuclideo.150.150.1.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 107462, 
        "name": "CapEuclideo.150.150.5.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 109451, 
        "name": "CapEuclideo.150.150.5.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 145, 
        "K": 150, 
        "best_cost": 117511, 
        "name": "CapEuclideo.150.150.5.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 124302, 
        "name": "CapEuclideo.150.150.5.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 108948, 
        "name": "CapEuclideo.150.150.5.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 41916, 
        "name": "CapEuclideo.150.150.7.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 143, 
        "K": 150, 
        "best_cost": 42012, 
        "name": "CapEuclideo.150.150.7.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 44216, 
        "name": "CapEuclideo.150.150.7.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 47464, 
        "name": "CapEuclideo.150.150.7.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 150, 
        "best_cost": 41680, 
        "name": "CapEuclideo.150.150.7.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 124, 
        "K": 150, 
        "best_cost": 21094, 
        "name": "CapEuclideo.150.150.8.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 147, 
        "K": 150, 
        "best_cost": 21862, 
        "name": "CapEuclideo.150.150.8.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 147, 
        "K": 150, 
        "best_cost": 22499, 
        "name": "CapEuclideo.150.150.8.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 143, 
        "K": 150, 
        "best_cost": 23852, 
        "name": "CapEuclideo.150.150.8.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 135, 
        "K": 150, 
        "best_cost": 21378, 
        "name": "CapEuclideo.150.150.8.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 102, 
        "K": 150, 
        "best_cost": 9518, 
        "name": "CapEuclideo.150.150.9.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 104, 
        "K": 150, 
        "best_cost": 9478, 
        "name": "CapEuclideo.150.150.9.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 107, 
        "K": 150, 
        "best_cost": 9456, 
        "name": "CapEuclideo.150.150.9.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 97, 
        "K": 150, 
        "best_cost": 9609, 
        "name": "CapEuclideo.150.150.9.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 99, 
        "K": 150, 
        "best_cost": 9398, 
        "name": "CapEuclideo.150.150.9.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 59, 
        "K": 150, 
        "best_cost": 4789, 
        "name": "CapEuclideo.150.150.95.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 57, 
        "K": 150, 
        "best_cost": 5099, 
        "name": "CapEuclideo.150.150.95.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 61, 
        "K": 150, 
        "best_cost": 5000, 
        "name": "CapEuclideo.150.150.95.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 62, 
        "K": 150, 
        "best_cost": 5271, 
        "name": "CapEuclideo.150.150.95.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 59, 
        "K": 150, 
        "best_cost": 5662, 
        "name": "CapEuclideo.150.150.95.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 20, 
        "K": 150, 
        "best_cost": 1702, 
        "name": "CapEuclideo.150.150.99.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 29, 
        "K": 150, 
        "best_cost": 2547, 
        "name": "CapEuclideo.150.150.99.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 31, 
        "K": 150, 
        "best_cost": 2596, 
        "name": "CapEuclideo.150.150.99.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 26, 
        "K": 150, 
        "best_cost": 2201, 
        "name": "CapEuclideo.150.150.99.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 25, 
        "K": 150, 
        "best_cost": 2828, 
        "name": "CapEuclideo.150.150.99.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 483201, 
        "name": "CapEuclideo.150.200.1.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 468101, 
        "name": "CapEuclideo.150.200.1.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 523733, 
        "name": "CapEuclideo.150.200.1.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 530511, 
        "name": "CapEuclideo.150.200.1.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 499070, 
        "name": "CapEuclideo.150.200.1.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 146821, 
        "name": "CapEuclideo.150.200.5.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 142406, 
        "name": "CapEuclideo.150.200.5.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 156032, 
        "name": "CapEuclideo.150.200.5.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 161572, 
        "name": "CapEuclideo.150.200.5.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 150057, 
        "name": "CapEuclideo.150.200.5.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 54207, 
        "name": "CapEuclideo.150.200.7.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 53007, 
        "name": "CapEuclideo.150.200.7.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 56585, 
        "name": "CapEuclideo.150.200.7.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 59935, 
        "name": "CapEuclideo.150.200.7.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 55194, 
        "name": "CapEuclideo.150.200.7.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 150, 
        "K": 200, 
        "best_cost": 26334, 
        "name": "CapEuclideo.150.200.8.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 200, 
        "best_cost": 25936, 
        "name": "CapEuclideo.150.200.8.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 200, 
        "best_cost": 27300, 
        "name": "CapEuclideo.150.200.8.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 148, 
        "K": 200, 
        "best_cost": 29012, 
        "name": "CapEuclideo.150.200.8.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 149, 
        "K": 200, 
        "best_cost": 27271, 
        "name": "CapEuclideo.150.200.8.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 111, 
        "K": 200, 
        "best_cost": 10195, 
        "name": "CapEuclideo.150.200.9.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 121, 
        "K": 200, 
        "best_cost": 10553, 
        "name": "CapEuclideo.150.200.9.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 116, 
        "K": 200, 
        "best_cost": 10463, 
        "name": "CapEuclideo.150.200.9.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 123, 
        "K": 200, 
        "best_cost": 11346, 
        "name": "CapEuclideo.150.200.9.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 114, 
        "K": 200, 
        "best_cost": 10875, 
        "name": "CapEuclideo.150.200.9.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 70, 
        "K": 200, 
        "best_cost": 5168, 
        "name": "CapEuclideo.150.200.95.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 73, 
        "K": 200, 
        "best_cost": 5682, 
        "name": "CapEuclideo.150.200.95.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 68, 
        "K": 200, 
        "best_cost": 5329, 
        "name": "CapEuclideo.150.200.95.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 74, 
        "K": 200, 
        "best_cost": 5866, 
        "name": "CapEuclideo.150.200.95.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 72, 
        "K": 200, 
        "best_cost": 6067, 
        "name": "CapEuclideo.150.200.95.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 29, 
        "K": 200, 
        "best_cost": 2073, 
        "name": "CapEuclideo.150.200.99.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 29, 
        "K": 200, 
        "best_cost": 2943, 
        "name": "CapEuclideo.150.200.99.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 33, 
        "K": 200, 
        "best_cost": 2256, 
        "name": "CapEuclideo.150.200.99.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 31, 
        "K": 200, 
        "best_cost": 2590, 
        "name": "CapEuclideo.150.200.99.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 31, 
        "K": 200, 
        "best_cost": 2905, 
        "name": "CapEuclideo.150.200.99.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 184696, 
        "name": "CapEuclideo.200.50.1.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 169938, 
        "name": "CapEuclideo.200.50.1.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 195103, 
        "name": "CapEuclideo.200.50.1.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 179172, 
        "name": "CapEuclideo.200.50.1.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 173355, 
        "name": "CapEuclideo.200.50.1.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 61360, 
        "name": "CapEuclideo.200.50.5.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 198, 
        "K": 50, 
        "best_cost": 55908, 
        "name": "CapEuclideo.200.50.5.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 62520, 
        "name": "CapEuclideo.200.50.5.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 50, 
        "best_cost": 58952, 
        "name": "CapEuclideo.200.50.5.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 189, 
        "K": 50, 
        "best_cost": 56235, 
        "name": "CapEuclideo.200.50.5.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 188, 
        "K": 50, 
        "best_cost": 27212, 
        "name": "CapEuclideo.200.50.7.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 185, 
        "K": 50, 
        "best_cost": 24546, 
        "name": "CapEuclideo.200.50.7.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 194, 
        "K": 50, 
        "best_cost": 26644, 
        "name": "CapEuclideo.200.50.7.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 187, 
        "K": 50, 
        "best_cost": 26082, 
        "name": "CapEuclideo.200.50.7.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 185, 
        "K": 50, 
        "best_cost": 24813, 
        "name": "CapEuclideo.200.50.7.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 148, 
        "K": 50, 
        "best_cost": 15555, 
        "name": "CapEuclideo.200.50.8.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 135, 
        "K": 50, 
        "best_cost": 13874, 
        "name": "CapEuclideo.200.50.8.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 158, 
        "K": 50, 
        "best_cost": 15714, 
        "name": "CapEuclideo.200.50.8.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 155, 
        "K": 50, 
        "best_cost": 15354, 
        "name": "CapEuclideo.200.50.8.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 157, 
        "K": 50, 
        "best_cost": 14749, 
        "name": "CapEuclideo.200.50.8.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 84, 
        "K": 50, 
        "best_cost": 7340, 
        "name": "CapEuclideo.200.50.9.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 84, 
        "K": 50, 
        "best_cost": 6402, 
        "name": "CapEuclideo.200.50.9.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 88, 
        "K": 50, 
        "best_cost": 6805, 
        "name": "CapEuclideo.200.50.9.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 88, 
        "K": 50, 
        "best_cost": 7277, 
        "name": "CapEuclideo.200.50.9.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 95, 
        "K": 50, 
        "best_cost": 7008, 
        "name": "CapEuclideo.200.50.9.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 52, 
        "K": 50, 
        "best_cost": 3924, 
        "name": "CapEuclideo.200.50.95.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 43, 
        "K": 50, 
        "best_cost": 3486, 
        "name": "CapEuclideo.200.50.95.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 50, 
        "K": 50, 
        "best_cost": 3548, 
        "name": "CapEuclideo.200.50.95.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 48, 
        "K": 50, 
        "best_cost": 4111, 
        "name": "CapEuclideo.200.50.95.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 51, 
        "K": 50, 
        "best_cost": 3792, 
        "name": "CapEuclideo.200.50.95.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 21, 
        "K": 50, 
        "best_cost": 1425, 
        "name": "CapEuclideo.200.50.99.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 17, 
        "K": 50, 
        "best_cost": 1137, 
        "name": "CapEuclideo.200.50.99.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 20, 
        "K": 50, 
        "best_cost": 1446, 
        "name": "CapEuclideo.200.50.99.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 22, 
        "K": 50, 
        "best_cost": 2237, 
        "name": "CapEuclideo.200.50.99.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 24, 
        "K": 50, 
        "best_cost": 2351, 
        "name": "CapEuclideo.200.50.99.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 197, 
        "K": 100, 
        "best_cost": 328659, 
        "name": "CapEuclideo.200.100.1.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 345088, 
        "name": "CapEuclideo.200.100.1.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 344957, 
        "name": "CapEuclideo.200.100.1.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 347295, 
        "name": "CapEuclideo.200.100.1.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 316743, 
        "name": "CapEuclideo.200.100.1.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 102850, 
        "name": "CapEuclideo.200.100.5.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 107166, 
        "name": "CapEuclideo.200.100.5.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 105480, 
        "name": "CapEuclideo.200.100.5.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 97634, 
        "name": "CapEuclideo.200.100.5.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 40444, 
        "name": "CapEuclideo.200.100.7.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 200, 
        "K": 100, 
        "best_cost": 41831, 
        "name": "CapEuclideo.200.100.7.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 191, 
        "K": 100, 
        "best_cost": 40733, 
        "name": "CapEuclideo.200.100.7.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 184, 
        "K": 100, 
        "best_cost": 21655, 
        "name": "CapEuclideo.200.100.8.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 175, 
        "K": 100, 
        "best_cost": 21527, 
        "name": "CapEuclideo.200.100.8.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 191, 
        "K": 100, 
        "best_cost": 21614, 
        "name": "CapEuclideo.200.100.8.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 190, 
        "K": 100, 
        "best_cost": 22537, 
        "name": "CapEuclideo.200.100.8.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 184, 
        "K": 100, 
        "best_cost": 20970, 
        "name": "CapEuclideo.200.100.8.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 125, 
        "K": 100, 
        "best_cost": 9262, 
        "name": "CapEuclideo.200.100.9.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 122, 
        "K": 100, 
        "best_cost": 9042, 
        "name": "CapEuclideo.200.100.9.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 127, 
        "K": 100, 
        "best_cost": 9389, 
        "name": "CapEuclideo.200.100.9.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 121, 
        "K": 100, 
        "best_cost": 9753, 
        "name": "CapEuclideo.200.100.9.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 118, 
        "K": 100, 
        "best_cost": 9506, 
        "name": "CapEuclideo.200.100.9.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 68, 
        "K": 100, 
        "best_cost": 4805, 
        "name": "CapEuclideo.200.100.95.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 74, 
        "K": 100, 
        "best_cost": 4863, 
        "name": "CapEuclideo.200.100.95.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 74, 
        "K": 100, 
        "best_cost": 4764, 
        "name": "CapEuclideo.200.100.95.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 72, 
        "K": 100, 
        "best_cost": 5289, 
        "name": "CapEuclideo.200.100.95.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 72, 
        "K": 100, 
        "best_cost": 5241, 
        "name": "CapEuclideo.200.100.95.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 28, 
        "K": 100, 
        "best_cost": 2039, 
        "name": "CapEuclideo.200.100.99.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 30, 
        "K": 100, 
        "best_cost": 2756, 
        "name": "CapEuclideo.200.100.99.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 28, 
        "K": 100, 
        "best_cost": 2224, 
        "name": "CapEuclideo.200.100.99.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 28, 
        "K": 100, 
        "best_cost": 2548, 
        "name": "CapEuclideo.200.100.99.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 23, 
        "K": 100, 
        "best_cost": 1867, 
        "name": "CapEuclideo.200.100.99.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 9, 
        "K": 50, 
        "best_cost": 1856, 
        "name": "EEuclideo.50.50.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 9, 
        "K": 50, 
        "best_cost": 1070, 
        "name": "EEuclideo.50.50.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 10, 
        "K": 50, 
        "best_cost": 1553, 
        "name": "EEuclideo.50.50.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 7, 
        "K": 50, 
        "best_cost": 1394, 
        "name": "EEuclideo.50.50.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 3, 
        "K": 50, 
        "best_cost": 1536, 
        "name": "EEuclideo.50.50.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 2397, 
        "name": "EEuclideo.50.100.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 12, 
        "K": 100, 
        "best_cost": 2138, 
        "name": "EEuclideo.50.100.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 11, 
        "K": 100, 
        "best_cost": 1852, 
        "name": "EEuclideo.50.100.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 16, 
        "K": 100, 
        "best_cost": 3093, 
        "name": "EEuclideo.50.100.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 2603, 
        "name": "EEuclideo.50.100.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 16, 
        "K": 150, 
        "best_cost": 2784, 
        "name": "EEuclideo.50.150.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 12, 
        "K": 150, 
        "best_cost": 2137, 
        "name": "EEuclideo.50.150.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 15, 
        "K": 150, 
        "best_cost": 2308, 
        "name": "EEuclideo.50.150.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 15, 
        "K": 150, 
        "best_cost": 2524, 
        "name": "EEuclideo.50.150.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 17, 
        "K": 150, 
        "best_cost": 3150, 
        "name": "EEuclideo.50.150.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 20, 
        "K": 200, 
        "best_cost": 3354, 
        "name": "EEuclideo.50.200.1.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 16, 
        "K": 200, 
        "best_cost": 2397, 
        "name": "EEuclideo.50.200.2.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 12, 
        "K": 200, 
        "best_cost": 2319, 
        "name": "EEuclideo.50.200.3.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 17, 
        "K": 200, 
        "best_cost": 2858, 
        "name": "EEuclideo.50.200.4.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 18, 
        "K": 200, 
        "best_cost": 3575, 
        "name": "EEuclideo.50.200.5.tpp", 
        "V": 50
    }, 
    {
        "best_markets": 10, 
        "K": 50, 
        "best_cost": 1468, 
        "name": "EEuclideo.100.50.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 8, 
        "K": 50, 
        "best_cost": 971, 
        "name": "EEuclideo.100.50.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 11, 
        "K": 50, 
        "best_cost": 1623, 
        "name": "EEuclideo.100.50.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 11, 
        "K": 50, 
        "best_cost": 1718, 
        "name": "EEuclideo.100.50.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 12, 
        "K": 50, 
        "best_cost": 2494, 
        "name": "EEuclideo.100.50.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 17, 
        "K": 100, 
        "best_cost": 2121, 
        "name": "EEuclideo.100.100.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 14, 
        "K": 100, 
        "best_cost": 1906, 
        "name": "EEuclideo.100.100.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 14, 
        "K": 100, 
        "best_cost": 1822, 
        "name": "EEuclideo.100.100.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 10, 
        "K": 100, 
        "best_cost": 1649, 
        "name": "EEuclideo.100.100.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 16, 
        "K": 100, 
        "best_cost": 2925, 
        "name": "EEuclideo.100.100.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 15, 
        "K": 150, 
        "best_cost": 2195, 
        "name": "EEuclideo.100.150.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 17, 
        "K": 150, 
        "best_cost": 2806, 
        "name": "EEuclideo.100.150.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 2257, 
        "name": "EEuclideo.100.150.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 20, 
        "K": 150, 
        "best_cost": 2625, 
        "name": "EEuclideo.100.150.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 3150, 
        "name": "EEuclideo.100.150.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 11, 
        "K": 200, 
        "best_cost": 1883, 
        "name": "EEuclideo.100.200.1.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 25, 
        "K": 200, 
        "best_cost": 3077, 
        "name": "EEuclideo.100.200.2.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 24, 
        "K": 200, 
        "best_cost": 2791, 
        "name": "EEuclideo.100.200.3.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 20, 
        "K": 200, 
        "best_cost": 3409, 
        "name": "EEuclideo.100.200.4.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 19, 
        "K": 200, 
        "best_cost": 2732, 
        "name": "EEuclideo.100.200.5.tpp", 
        "V": 100
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 1658, 
        "name": "EEuclideo.150.50.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 8, 
        "K": 50, 
        "best_cost": 1383, 
        "name": "EEuclideo.150.50.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 8, 
        "K": 50, 
        "best_cost": 821, 
        "name": "EEuclideo.150.50.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 11, 
        "K": 50, 
        "best_cost": 1676, 
        "name": "EEuclideo.150.50.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 1823, 
        "name": "EEuclideo.150.50.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 18, 
        "K": 100, 
        "best_cost": 1717, 
        "name": "EEuclideo.150.100.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 12, 
        "K": 100, 
        "best_cost": 1798, 
        "name": "EEuclideo.150.100.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 17, 
        "K": 100, 
        "best_cost": 1959, 
        "name": "EEuclideo.150.100.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 15, 
        "K": 100, 
        "best_cost": 1609, 
        "name": "EEuclideo.150.100.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 15, 
        "K": 100, 
        "best_cost": 1585, 
        "name": "EEuclideo.150.100.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 20, 
        "K": 150, 
        "best_cost": 1669, 
        "name": "EEuclideo.150.150.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 25, 
        "K": 150, 
        "best_cost": 2526, 
        "name": "EEuclideo.150.150.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 20, 
        "K": 150, 
        "best_cost": 2456, 
        "name": "EEuclideo.150.150.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 17, 
        "K": 150, 
        "best_cost": 1761, 
        "name": "EEuclideo.150.150.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 2355, 
        "name": "EEuclideo.150.150.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 20, 
        "K": 200, 
        "best_cost": 1760, 
        "name": "EEuclideo.150.200.1.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 25, 
        "K": 200, 
        "best_cost": 2312, 
        "name": "EEuclideo.150.200.2.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 26, 
        "K": 200, 
        "best_cost": 2594, 
        "name": "EEuclideo.150.200.3.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 16, 
        "K": 200, 
        "best_cost": 1889, 
        "name": "EEuclideo.150.200.4.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 23, 
        "K": 200, 
        "best_cost": 2472, 
        "name": "EEuclideo.150.200.5.tpp", 
        "V": 150
    }, 
    {
        "best_markets": 14, 
        "K": 50, 
        "best_cost": 1102, 
        "name": "EEuclideo.200.50.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 7, 
        "K": 50, 
        "best_cost": 607, 
        "name": "EEuclideo.200.50.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 7, 
        "K": 50, 
        "best_cost": 530, 
        "name": "EEuclideo.200.50.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 10, 
        "K": 50, 
        "best_cost": 908, 
        "name": "EEuclideo.200.50.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 12, 
        "K": 50, 
        "best_cost": 1067, 
        "name": "EEuclideo.200.50.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 949, 
        "name": "EEuclideo.200.100.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 19, 
        "K": 100, 
        "best_cost": 2271, 
        "name": "EEuclideo.200.100.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 14, 
        "K": 100, 
        "best_cost": 1611, 
        "name": "EEuclideo.200.100.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 18, 
        "K": 100, 
        "best_cost": 1799, 
        "name": "EEuclideo.200.100.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 29, 
        "K": 100, 
        "best_cost": 3161, 
        "name": "EEuclideo.200.100.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 17, 
        "K": 150, 
        "best_cost": 1730, 
        "name": "EEuclideo.200.150.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 28, 
        "K": 150, 
        "best_cost": 2745, 
        "name": "EEuclideo.200.150.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 21, 
        "K": 150, 
        "best_cost": 1861, 
        "name": "EEuclideo.200.150.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 24, 
        "K": 150, 
        "best_cost": 2419, 
        "name": "EEuclideo.200.150.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 2079, 
        "name": "EEuclideo.200.150.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 19, 
        "K": 200, 
        "best_cost": 1736, 
        "name": "EEuclideo.200.200.1.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 23, 
        "K": 200, 
        "best_cost": 2352, 
        "name": "EEuclideo.200.200.2.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 24, 
        "K": 200, 
        "best_cost": 2505, 
        "name": "EEuclideo.200.200.3.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 21, 
        "K": 200, 
        "best_cost": 2344, 
        "name": "EEuclideo.200.200.4.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 24, 
        "K": 200, 
        "best_cost": 2427, 
        "name": "EEuclideo.200.200.5.tpp", 
        "V": 200
    }, 
    {
        "best_markets": 7, 
        "K": 50, 
        "best_cost": 533, 
        "name": "EEuclideo.250.50.1.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 11, 
        "K": 50, 
        "best_cost": 1103, 
        "name": "EEuclideo.250.50.2.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 13, 
        "K": 50, 
        "best_cost": 1295, 
        "name": "EEuclideo.250.50.3.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 14, 
        "K": 50, 
        "best_cost": 1553, 
        "name": "EEuclideo.250.50.4.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 6, 
        "K": 50, 
        "best_cost": 1142, 
        "name": "EEuclideo.250.50.5.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 12, 
        "K": 100, 
        "best_cost": 1301, 
        "name": "EEuclideo.250.100.1.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 13, 
        "K": 100, 
        "best_cost": 932, 
        "name": "EEuclideo.250.100.2.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 18, 
        "K": 100, 
        "best_cost": 1361, 
        "name": "EEuclideo.250.100.3.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 17, 
        "K": 100, 
        "best_cost": 1673, 
        "name": "EEuclideo.250.100.4.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 15, 
        "K": 100, 
        "best_cost": 1641, 
        "name": "EEuclideo.250.100.5.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 16, 
        "K": 150, 
        "best_cost": 1168, 
        "name": "EEuclideo.250.150.1.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 23, 
        "K": 150, 
        "best_cost": 2205, 
        "name": "EEuclideo.250.150.2.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 16, 
        "K": 150, 
        "best_cost": 1582, 
        "name": "EEuclideo.250.150.3.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 19, 
        "K": 150, 
        "best_cost": 1836, 
        "name": "EEuclideo.250.150.4.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 16, 
        "K": 150, 
        "best_cost": 1531, 
        "name": "EEuclideo.250.150.5.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 21, 
        "K": 200, 
        "best_cost": 1677, 
        "name": "EEuclideo.250.200.1.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 26, 
        "K": 200, 
        "best_cost": 2785, 
        "name": "EEuclideo.250.200.2.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 26, 
        "K": 200, 
        "best_cost": 1924, 
        "name": "EEuclideo.250.200.3.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 18, 
        "K": 200, 
        "best_cost": 2116, 
        "name": "EEuclideo.250.200.4.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 19, 
        "K": 200, 
        "best_cost": 1797, 
        "name": "EEuclideo.250.200.5.tpp", 
        "V": 250
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 1477, 
        "name": "EEuclideo.300.50.1.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 813, 
        "name": "EEuclideo.300.50.2.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 1117, 
        "name": "EEuclideo.300.50.3.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 1176, 
        "name": "EEuclideo.300.50.4.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 1256, 
        "name": "EEuclideo.300.50.5.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1035, 
        "name": "EEuclideo.300.100.1.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1179, 
        "name": "EEuclideo.300.100.2.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1498, 
        "name": "EEuclideo.300.100.3.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1749, 
        "name": "EEuclideo.300.100.4.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1774, 
        "name": "EEuclideo.300.100.5.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1457, 
        "name": "EEuclideo.300.150.1.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1656, 
        "name": "EEuclideo.300.150.2.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 2484, 
        "name": "EEuclideo.300.150.3.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1801, 
        "name": "EEuclideo.300.150.4.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1816, 
        "name": "EEuclideo.300.150.5.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1803, 
        "name": "EEuclideo.300.200.1.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1790, 
        "name": "EEuclideo.300.200.2.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 2437, 
        "name": "EEuclideo.300.200.3.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1815, 
        "name": "EEuclideo.300.200.4.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 2014, 
        "name": "EEuclideo.300.200.5.tpp", 
        "V": 300
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 723, 
        "name": "EEuclideo.350.50.1.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 736, 
        "name": "EEuclideo.350.50.2.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 942, 
        "name": "EEuclideo.350.50.3.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 805, 
        "name": "EEuclideo.350.50.4.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 50, 
        "best_cost": 1125, 
        "name": "EEuclideo.350.50.5.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1317, 
        "name": "EEuclideo.350.100.1.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 962, 
        "name": "EEuclideo.350.100.2.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 796, 
        "name": "EEuclideo.350.100.3.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1059, 
        "name": "EEuclideo.350.100.4.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 100, 
        "best_cost": 1566, 
        "name": "EEuclideo.350.100.5.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1457, 
        "name": "EEuclideo.350.150.1.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1315, 
        "name": "EEuclideo.350.150.2.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 2553, 
        "name": "EEuclideo.350.150.3.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 1239, 
        "name": "EEuclideo.350.150.4.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 150, 
        "best_cost": 2288, 
        "name": "EEuclideo.350.150.5.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1498, 
        "name": "EEuclideo.350.200.1.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1369, 
        "name": "EEuclideo.350.200.2.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1873, 
        "name": "EEuclideo.350.200.3.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 1356, 
        "name": "EEuclideo.350.200.4.tpp", 
        "V": 350
    }, 
    {
        "best_markets": 0, 
        "K": 200, 
        "best_cost": 2336, 
        "name": "EEuclideo.350.200.5.tpp", 
        "V": 350
    }
]
